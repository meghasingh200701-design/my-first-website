# My First Website: Biotechnology & AI

A simple, responsive website for the JECRC University Digital, Data & AI Literacy assignment.

## Files
- `index.html` — complete website (HTML and CSS included).

## Run locally
Open `index.html` in a web browser.

## Publish using GitHub and Vercel
1. Create a new repository on GitHub named `my-first-website`.
2. Upload `index.html` and `README.md` to the repository.
3. In Vercel, choose **Add New Project** and import this GitHub repository.
4. Click **Deploy**. Vercel will provide a public website URL.
5. To update the site, edit `index.html` in GitHub and commit the changes. Vercel can automatically redeploy.
6. Optional: add a custom domain in Vercel project **Settings → Domains**. A domain may require payment.

## Student note
Personalize this website before submitting it. Add your own name or student details only if your instructor expects them.
